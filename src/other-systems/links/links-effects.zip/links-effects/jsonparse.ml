type token =
  | LBRACE
  | RBRACE
  | LBRACKET
  | RBRACKET
  | LPAREN
  | RPAREN
  | COLON
  | COMMA
  | UNDERSCORE
  | TRUE
  | FALSE
  | NULL
  | STRING of (string)
  | INT of (int)
  | FLOAT of (float)

open Parsing;;
let _ = parse_error;;
# 2 "jsonparse.mly"
open Utility
module Env = Env_links
(* let unparse_label = function *)
(*   | `Char c -> String.make 1 c *)
(*   | `List (`Char _::_) as s -> Value.unbox_string s *)
(*   | r -> (failwith "(json) error decoding label " ^ Show.show Value.show_t r) *)

(* BUG: need to unescape strings
   (where they are escaped in json.ml)
*)

# 33 "jsonparse.ml"
let yytransl_const = [|
  257 (* LBRACE *);
  258 (* RBRACE *);
  259 (* LBRACKET *);
  260 (* RBRACKET *);
  261 (* LPAREN *);
  262 (* RPAREN *);
  263 (* COLON *);
  264 (* COMMA *);
  265 (* UNDERSCORE *);
  266 (* TRUE *);
  267 (* FALSE *);
  268 (* NULL *);
    0|]

let yytransl_block = [|
  269 (* STRING *);
  270 (* INT *);
  271 (* FLOAT *);
    0|]

let yylhs = "\255\255\
\001\000\003\000\003\000\004\000\004\000\006\000\006\000\007\000\
\007\000\002\000\002\000\002\000\002\000\002\000\002\000\002\000\
\008\000\005\000\009\000\009\000\000\000"

let yylen = "\002\000\
\001\000\002\000\003\000\003\000\005\000\002\000\003\000\001\000\
\003\000\001\000\001\000\001\000\001\000\001\000\001\000\001\000\
\001\000\001\000\001\000\001\000\002\000"

let yydefred = "\000\000\
\000\000\000\000\000\000\000\000\014\000\015\000\016\000\017\000\
\020\000\019\000\021\000\001\000\012\000\013\000\010\000\011\000\
\002\000\018\000\000\000\000\000\006\000\008\000\000\000\003\000\
\000\000\000\000\007\000\000\000\000\000\004\000\009\000\000\000\
\005\000"

let yydgoto = "\002\000\
\011\000\012\000\013\000\019\000\020\000\014\000\023\000\015\000\
\016\000"

let yysindex = "\004\000\
\006\255\000\000\021\255\000\255\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\023\255\001\255\000\000\000\000\254\254\000\000\
\013\255\006\255\000\000\006\255\020\255\000\000\000\000\006\255\
\000\000"

let yyrindex = "\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000"

let yygindex = "\000\000\
\000\000\252\255\000\000\000\000\005\000\000\000\000\000\000\000\
\000\000"

let yytablesize = 34
let yytable = "\022\000\
\003\000\027\000\004\000\021\000\001\000\028\000\003\000\026\000\
\004\000\005\000\006\000\007\000\008\000\009\000\010\000\005\000\
\006\000\007\000\008\000\009\000\010\000\030\000\017\000\031\000\
\024\000\018\000\032\000\033\000\000\000\029\000\025\000\000\000\
\000\000\018\000"

let yycheck = "\004\000\
\001\001\004\001\003\001\004\001\001\000\008\001\001\001\007\001\
\003\001\010\001\011\001\012\001\013\001\014\001\015\001\010\001\
\011\001\012\001\013\001\014\001\015\001\026\000\002\001\028\000\
\002\001\013\001\007\001\032\000\255\255\025\000\008\001\255\255\
\255\255\013\001"

let yynames_const = "\
  LBRACE\000\
  RBRACE\000\
  LBRACKET\000\
  RBRACKET\000\
  LPAREN\000\
  RPAREN\000\
  COLON\000\
  COMMA\000\
  UNDERSCORE\000\
  TRUE\000\
  FALSE\000\
  NULL\000\
  "

let yynames_block = "\
  STRING\000\
  INT\000\
  FLOAT\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'value) in
    Obj.repr(
# 27 "jsonparse.mly"
        ( _1 )
# 137 "jsonparse.ml"
               : Value.t))
; (fun __caml_parser_env ->
    Obj.repr(
# 30 "jsonparse.mly"
                        ( `Record [] )
# 143 "jsonparse.ml"
               : 'object_))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'members) in
    Obj.repr(
# 31 "jsonparse.mly"
                        ( match _2 with 
                            | ["_c", c] -> Value.box_char ((Value.unbox_string c).[0])
                            | ["_label", l; "_value", v]
                            | ["_value", v; "_label", l] -> `Variant (Value.unbox_string l, v)
                            | ["_db", db] ->
                                begin
                                  match db with
                                    | `Record bs ->
                                        let driver = Value.unbox_string (List.assoc "driver" bs)
                                        and params =
                                          Value.reconstruct_db_string
                                            (Value.unbox_string (List.assoc "name" bs),
                                             Value.unbox_string (List.assoc "args" bs)) in
                                          `Database (Value.db_connect driver params) 
                                    | _ -> failwith ("jsonparse: database value must be a record")
                                end
                            | ["_table", t] ->
                                begin
                                  match t with
                                    | `Record bs ->
                                        let db =
                                          begin
                                            match List.assoc "db" bs with
                                              | `Database db -> db
                                              | _ -> failwith ("jsonparse: first argument to a table must be a database")
                                          end
                                        and name = Value.unbox_string (List.assoc "name" bs)
                                        and row =
                                          begin
                                            match DesugarDatatypes.read ~aliases:Env.String.empty (Value.unbox_string (List.assoc "row" bs)) with
                                                | `Record row -> row
                                                | _ -> failwith ("jsonparse: tables must have record type")
                                          end
                                        in
                                          `Table (db, name, row)
                                    | _ -> failwith ("jsonparse: table value must be a record")
                                end
                            | ["_xml", t] ->
                                  begin
                                    match t with
                                      | `List [node_type; s] when (Value.unbox_string node_type = "TEXT") ->
                                          `XML (Value.Text (Value.unbox_string s))
                                      | `List [node_type; tag; attrs; body]
                                          when (Value.unbox_string node_type = "ELEMENT") ->
                                          let tag = Value.unbox_string tag in
                                          let attrs =
                                            match attrs with
                                              | `Record attrs -> attrs
                                              | _ -> failwith ("jsonparse: xml attributes should be an attribute record") in
                                            let attrs =
                                              List.fold_left
                                                (fun attrs (label, value) ->
                                                   Value.Attr (label, Value.unbox_string value) :: attrs)
                                                [] attrs in
                                              let body =
                                                match body with
                                                  | `List body -> List.map
                                                      (function 
                                                         | `XML body -> body
                                                         | _ -> failwith ("jsonparse: xml body should be a list of xmlitems"))
                                                        body
                                                  | _ -> failwith ("jsonparse: xml body should be a list of xmlitems")
                                              in
                                                `XML (Value.Node (tag, attrs @ body))
                                      | _ ->
                                          failwith ("jsonparse: xml should be either a text node or an element node. Got: "
                                                    ^ Value.string_of_value t)
                                  end
                            | ["_closureTable", id] ->
                              `ClientFunction("_closureTable["^Value.string_of_value id^"]")
                            | ["_serverFunc", id] ->
                              `FunctionPtr(Value.unbox_int id, Value.empty_env)
                            | ["_serverFunc", id; "_env", env]
                            | ["_env", env; "_serverFunc", id] ->
                              let env' =
                                Value.extend Value.empty_env
                                  (Utility.IntMap.map
                                     (fun v -> (v, `Local))
                                     (Utility.val_of (Value.intmap_of_record env)))
                              in
                              `FunctionPtr(Value.unbox_int id, env')
                            | _ -> `Record (List.rev _2)
                        )
# 232 "jsonparse.ml"
               : 'object_))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'id) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'value) in
    Obj.repr(
# 116 "jsonparse.mly"
                                     ( [_1, _3] )
# 240 "jsonparse.ml"
               : 'members))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 4 : 'members) in
    let _3 = (Parsing.peek_val __caml_parser_env 2 : 'id) in
    let _5 = (Parsing.peek_val __caml_parser_env 0 : 'value) in
    Obj.repr(
# 117 "jsonparse.mly"
                                     ( (_3, _5) :: _1 )
# 249 "jsonparse.ml"
               : 'members))
; (fun __caml_parser_env ->
    Obj.repr(
# 120 "jsonparse.mly"
                                     ( `List ([]) )
# 255 "jsonparse.ml"
               : 'array))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'elements) in
    Obj.repr(
# 121 "jsonparse.mly"
                                     ( `List (List.rev _2) )
# 262 "jsonparse.ml"
               : 'array))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'value) in
    Obj.repr(
# 124 "jsonparse.mly"
                                     ( [_1] )
# 269 "jsonparse.ml"
               : 'elements))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'elements) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'value) in
    Obj.repr(
# 125 "jsonparse.mly"
                                     ( _3 :: _1 )
# 277 "jsonparse.ml"
               : 'elements))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'string) in
    Obj.repr(
# 128 "jsonparse.mly"
                                     ( _1 )
# 284 "jsonparse.ml"
               : 'value))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'number) in
    Obj.repr(
# 129 "jsonparse.mly"
                                     ( _1 )
# 291 "jsonparse.ml"
               : 'value))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'object_) in
    Obj.repr(
# 130 "jsonparse.mly"
                                     ( _1 )
# 298 "jsonparse.ml"
               : 'value))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'array) in
    Obj.repr(
# 131 "jsonparse.mly"
                                     ( _1 )
# 305 "jsonparse.ml"
               : 'value))
; (fun __caml_parser_env ->
    Obj.repr(
# 132 "jsonparse.mly"
                                     ( `Bool true )
# 311 "jsonparse.ml"
               : 'value))
; (fun __caml_parser_env ->
    Obj.repr(
# 133 "jsonparse.mly"
                                     ( `Bool false )
# 317 "jsonparse.ml"
               : 'value))
; (fun __caml_parser_env ->
    Obj.repr(
# 134 "jsonparse.mly"
                                     ( `Record [] (* Or an error? *) )
# 323 "jsonparse.ml"
               : 'value))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 137 "jsonparse.mly"
                                     ( Value.box_string _1 )
# 330 "jsonparse.ml"
               : 'string))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 139 "jsonparse.mly"
                                     ( _1 )
# 337 "jsonparse.ml"
               : 'id))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : float) in
    Obj.repr(
# 142 "jsonparse.mly"
                                    ( `Float _1 )
# 344 "jsonparse.ml"
               : 'number))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : int) in
    Obj.repr(
# 143 "jsonparse.mly"
                                    ( `Int _1 )
# 351 "jsonparse.ml"
               : 'number))
(* Entry parse_json *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
|]
let yytables =
  { Parsing.actions=yyact;
    Parsing.transl_const=yytransl_const;
    Parsing.transl_block=yytransl_block;
    Parsing.lhs=yylhs;
    Parsing.len=yylen;
    Parsing.defred=yydefred;
    Parsing.dgoto=yydgoto;
    Parsing.sindex=yysindex;
    Parsing.rindex=yyrindex;
    Parsing.gindex=yygindex;
    Parsing.tablesize=yytablesize;
    Parsing.table=yytable;
    Parsing.check=yycheck;
    Parsing.error_function=parse_error;
    Parsing.names_const=yynames_const;
    Parsing.names_block=yynames_block }
let parse_json (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 1 lexfun lexbuf : Value.t)
