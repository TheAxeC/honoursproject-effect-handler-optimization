(**
 Whether to run the interactive loop
 (default is true)
*)
let interacting = Settings.add_bool ("interacting", true, `System)

(* Dump lambda IR *)
let show_lambda_ir = Settings.add_bool("show_lambda_ir", false, `User)
let show_clambda_ir = Settings.add_bool("show_clambda_ir", false, `User)
let show_compiled_ir = Settings.add_bool("show_anf_ir", false, `User) (* FIXME: Duplicate of Sugartoir.show_compiled_ir.*)				       

(* Compiling *)
let compile_mode = Settings.add_bool("compile_mode", false, `System)
let codegenerator = Settings.add_string("codegenerator", "native", `System)  
let dry_run   = Settings.add_bool("dry_run", false, `System) (* Simulate compilation, but don't emit any code *)
let output_file = Settings.add_string("output_file", "a.out", `System)
let verbose     = Settings.add_bool("verbose", false, `System)

  
(** [true] if we're in web mode *)
let web_mode = Settings.add_bool ("web_mode", false, `System)

(** If [true], then wait for all child processes to finish before
    terminating *)
let wait_for_child_processes = Settings.add_bool ("wait_for_child_processes", false, `User)

(** If [true], then enable concurrency on the server:

    - Child processes are abandoned if the main process ends.

    - A run-time error results if the server tries to call the client
    with child processes still running.
*)
let concurrent_server = Settings.add_bool ("concurrent_server", true, `System)

(** Set this to [true] to print types when printing results. *)
let printing_types = Settings.add_bool ("printing_types", true, `User)

(** Name of the file containing the prelude code. *)
let prelude_file =
  let prelude_src =
    if Settings.get_value compile_mode
    then "prelude_compiler.links"
    else "prelude.links"
  in
  let prelude_dir = match Utility.getenv "LINKS_LIB" with
      None -> Filename.dirname Sys.executable_name 
    | Some path ->
       let prelude = Filename.concat path prelude_src in
       if not (Sys.file_exists prelude)
       then Filename.dirname Sys.executable_name
       else path
  in
  Settings.add_string ("prelude", Filename.concat prelude_dir prelude_src, `System)

(* FIXME: Have one prelude *)
let prelude_file_compiler = 
  let prelude_dir = Filename.dirname Sys.executable_name in
  let prelude_src = "prelude_compiler.links" in
  Settings.add_string ("prelude_compiler", Filename.concat prelude_dir prelude_src, `System)


let load_prelude = Settings.add_bool ("load_prelude", true, `System)

(** The banner *)
let welcome_note = Settings.add_string ("welcome_note", 
" _     _ __   _ _  __  ___\n\
 / |   | |  \\ | | |/ / / ._\\\n\
 | |   | | , \\| |   /  \\  \\\n\
 | |___| | |\\ \\ | |\\ \\ _\\  \\\n\
 |_____|_|_| \\__|_| \\_|____/\n\
Welcome to Links with effect handlers", `System)

(* (* Alternative banner designs *)
"  _     _ __    _ _  __  ___
 / |   | |  \\  |   |/ / / ._\\
 | |   | | , \\ | |   /  \\  \\
 | |___| | |\\ \\  | |\\ \\__\\  \\
 |_____._._| \\___|_| \\______/",
"                                         _
  _     _ __    _ _  _ ___        <>    |_>
 / |   | |  \\  | | |'// ._\\      //     |  
 | |   | | , \\ | |  / \\  \\      //      |
 | |___| | |\\ \\  | | \\_\\  \\  ,-//      _|_
 |_____._._| \\___|_|\\_____/  \\_/      <_|_>"
*)

(** Allow impure top-level definitions *)
let allow_impure_defs = Settings.add_bool("allow_impure_defs", false, `User)

(** JS stuff *)
(* needs to go here as long as we have two different JS compilers *)
module Js =
struct
  let optimise = Settings.add_bool("optimise_javascript", true, `User)
  let elim_dead_defs = Settings.add_bool("elim_dead_defs", false, `User)
  let lib_url = Settings.add_string("jsliburl", "lib/", `User)
  let pp = Settings.add_bool("js_pretty_print", true, `User)

  let hide_database_info = Settings.add_bool("js_hide_database_info", true, `System)
end

(** Caveat: don't [Open basicsettings] because the above module
   conflicts with the Js module from js.ml*)

(** Installed preprocessor *)
let pp = Settings.add_string("preprocessor", "", `System)

(** Default database settings *)
let database_driver = Settings.add_string("database_driver", "", `User)
let database_args = Settings.add_string("database_args", "", `User)

(** Set this to [true] to print the body and environment of a
    function. When [false], functions are simply printed as [fun] *)
let printing_functions = Settings.add_bool ("printing_functions", false, `User)

(** Caching *)
let cache_directory = 
  Settings.add_string ("cache_directory", "", `User)
let use_cache = Settings.add_bool("use_cache", true, `System)
let make_cache = Settings.add_bool("make_cache", true, `System)

(* if set to true, then Links will not check that the
   cache is newer than the Links binary
*)
let allow_stale_cache = Settings.add_bool("allow_stale_cache", false, `System)

(* Optimization pass? *)
let optimise = Settings.add_bool("optimise", false, `User)

(* Compile & cache whole program, closures, and HTML *)
let cache_whole_program = Settings.add_bool("cache_whole_program", false, `User)
